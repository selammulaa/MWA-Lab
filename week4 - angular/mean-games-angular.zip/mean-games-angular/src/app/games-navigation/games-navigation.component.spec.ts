import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GamesNavigationComponent } from './games-navigation.component';

describe('GamesNavigationComponent', () => {
  let component: GamesNavigationComponent;
  let fixture: ComponentFixture<GamesNavigationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GamesNavigationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GamesNavigationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
