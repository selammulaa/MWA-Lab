import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-games-navigation',
  templateUrl: './games-navigation.component.html',
  styleUrls: ['./games-navigation.component.css']
})
export class GamesNavigationComponent implements OnInit {

  loggedInUser: string = "Selam";

  constructor() { }

  ngOnInit(): void {
  }

}
