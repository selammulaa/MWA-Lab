export interface Location {
    coordinates: number[];
}

export interface Publisher {
    location: Location;
    _id: string;
    name: string;
}

export interface Review {
    _id: string;
    review: string;
}

export class Game {
    designers: string[];
    rate: number;
    _id: string;
    title: string;
    year: number;
    price: number;
    minPlayers: number;
    maxPlayers: number;
    publisher: Publisher;
    reviews: Review[];
    minAge: number;
}


