import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-game-rating',
  templateUrl: './game-rating.component.html',
  styleUrls: ['./game-rating.component.css']
})
export class GameRatingComponent implements OnInit {

  @Input() rating: number;

  constructor() { }

  ngOnInit(): void {
  }

}
