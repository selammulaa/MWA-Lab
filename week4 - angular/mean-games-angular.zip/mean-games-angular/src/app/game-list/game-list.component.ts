import { Component, OnInit } from '@angular/core';

import { Game } from '../game';
import { GameDataServiceService } from '../game-data-service.service';

@Component({
  selector: 'app-game-list',
  templateUrl: './game-list.component.html',
  styleUrls: ['./game-list.component.css']
})
export class GameListComponent implements OnInit {

  games: Game[];
  search: string;
  game: Game = new Game();
  isLoggedIn: boolean;

  constructor(private gameDataService : GameDataServiceService) { }

  ngOnInit(): void {
    this.getGames();
  }

  private getGames(): void {
    this.gameDataService.getGames()
      .then(foundGames => {
        this.games = foundGames;
        this.isLoggedIn =  this.gameDataService.isLoggedIn
      });
  }

  searchGames(){
    this.gameDataService.searchGames(this.search)
      .then(foundGames => {
        this.games = foundGames;
      });
  }

  save(){
    console.log(this.game);
    this.game.reviews = [];
    this.gameDataService.saveGame(this.game)
      .then((newGame) => {
        console.log(newGame);
        this.game = new Game();
      }).catch(err => {
        console.log(err);
      })
  }

}
