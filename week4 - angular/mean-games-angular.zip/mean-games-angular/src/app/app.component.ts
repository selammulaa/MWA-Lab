import { Component } from '@angular/core';

import { GameDataServiceService } from './game-data-service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  username: string;
  password: string;

  isLoggedIn: boolean;

  constructor(private gameDataService: GameDataServiceService){

  }

  onLogin(): void{
    let user = {
      username: this.username,
      password: this.password
    }
    this.gameDataService.login(user)
      .then(response => {
        console.log(response)
        this.gameDataService.isLoggedIn = true;
        this.isLoggedIn = true;
      }).catch(err => {
        console.log(err);
      })
  }

  onLogout(): void{
    console.log(this.gameDataService.isLoggedIn);
    this.gameDataService.isLoggedIn = false;
    this.isLoggedIn = false;
  }
}
