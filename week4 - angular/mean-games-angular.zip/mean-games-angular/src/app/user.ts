export class User {
    name: string;
    username: string;
    password: string;
    passwordRepeat: string;
}