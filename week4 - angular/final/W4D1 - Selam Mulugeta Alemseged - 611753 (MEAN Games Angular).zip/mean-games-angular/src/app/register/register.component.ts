import { Component, OnInit } from '@angular/core';
import { GameDataServiceService } from '../game-data-service.service';
import { User } from '../user';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  user: User = new User();
  err: string;
  message: string;
  showMessage: boolean = false;
  showError: boolean = false;

  constructor(private gameService: GameDataServiceService) { }

  ngOnInit(): void {
  }

  register(){
    console.log(this.user);
    if(this.user.password !== this.user.passwordRepeat){
      this.err = "Please make sure the password mathch.";
      return;
    }
    this.gameService.register(this.user)
      .then(user => {
        this.message = "Successful registration, please login.";
      })
      .catch(err => {
        this.err = "Error Occured";
      })
  }

}
