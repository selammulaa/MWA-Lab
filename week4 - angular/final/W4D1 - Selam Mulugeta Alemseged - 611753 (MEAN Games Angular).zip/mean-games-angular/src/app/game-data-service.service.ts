import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Game } from "./game";
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class GameDataServiceService {

  private apiBaseUrl = "http://localhost:3000/api";
  isLoggedIn: boolean = false;

  constructor(private http: HttpClient) { }

  public getGames(): Promise<Game[]>{
    const url: string = this.apiBaseUrl + "/games";

    return this.http
                .get(url)
                .toPromise()
                .then(respons => respons as Game[])
                .catch(this.handleErrors);
  }

  public searchGames(searchString: string): Promise<Game[]> {
    const url: string = this.apiBaseUrl + "/games?search=" + searchString;

    return this.http
                .get(url)
                .toPromise()
                .then(respons => respons as Game[])
                .catch(this.handleErrors);
  }

  public getGame(id: string): Promise<Game>{
    const url: string = this.apiBaseUrl + "/games/"+id;

    return this.http.get(url)
                    .toPromise()
                    .then(respons => respons as Game)
                    .catch(this.handleErrors);
  }

  public saveGame(game: Game): Promise<Game>{
    const url: string = this.apiBaseUrl + "/games/";

    return this.http.post(url, game)
                    .toPromise()
                    .then(response => response as Game)
                    .catch(this.handleErrors);
  }

  public deleteGame(id: string): Promise<any> {
    const url: string = this.apiBaseUrl + "/games/"+id;

    return this.http.delete(url)
      .toPromise()
      .then(response => response)
      .catch(this.handleErrors);
  }

  public login(user: any): Promise<any>{
    const url: string = this.apiBaseUrl + "/users/login";

    return this.http.post(url, user)
        .toPromise()
        .then(response => response)
        .catch(this.handleErrors);
  }

  public register(user: User): Promise<User>{
    const url: string = this.apiBaseUrl + "/users/register";

    return this.http.post(url, user)
      .toPromise()
      .then(respons => respons as User)
      .catch(this.handleErrors);

  }

  private handleErrors(error: any):Promise<any>{
    console.log("");
    return Promise.reject(error.message || error);
  }
}
