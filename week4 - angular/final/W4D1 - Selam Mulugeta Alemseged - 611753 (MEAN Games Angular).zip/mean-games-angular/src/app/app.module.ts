import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from "@angular/common/http";
import { RouterModule, Routes } from "@angular/router";
import { FormsModule, NgForm } from '@angular/forms';


import { GameDataServiceService } from './game-data-service.service';

import { AppComponent } from './app.component';
import { GameListComponent } from './game-list/game-list.component';
import { GamesNavigationComponent } from './games-navigation/games-navigation.component';
import { GameDetailComponent } from './game-detail/game-detail.component';
import { GameRatingComponent } from './game-rating/game-rating.component';
import { HomeComponent } from './home/home.component';
import { RegisterComponent } from './register/register.component';

const routes: Routes = [
  {path: '', redirectTo: '/home', pathMatch: 'full'},
  {path: 'home', component: HomeComponent},
  {path: "games", component: GameListComponent},
  {path: "games/:id", component: GameDetailComponent},
  {path: "register", component: RegisterComponent}

]

@NgModule({
  declarations: [
    AppComponent,
    GameListComponent,
    GamesNavigationComponent,
    GameDetailComponent,
    GameRatingComponent,
    HomeComponent,
    RegisterComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot(routes)
  ],
  providers: [ GameDataServiceService ],
  bootstrap: [AppComponent]
})
export class AppModule { }
