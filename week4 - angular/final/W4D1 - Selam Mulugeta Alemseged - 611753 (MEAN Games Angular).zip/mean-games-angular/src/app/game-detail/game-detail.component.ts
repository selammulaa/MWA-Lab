import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';

import { Game } from '../game';
import { GameDataServiceService } from '../game-data-service.service';

@Component({
  selector: 'app-game-detail',
  templateUrl: './game-detail.component.html',
  styleUrls: ['./game-detail.component.css']
})
export class GameDetailComponent implements OnInit {

  game: Game;
  deleteSuccess: boolean;
  deleteFailur: boolean;
  starRating: number[];

  constructor(
    private route: ActivatedRoute,
    private gameService: GameDataServiceService,
    private location: Location
  ) { }

  ngOnInit(): void {
    this.getGame();
  }

  getGame(): void {
    const id = this.route.snapshot.paramMap.get('id');
    this.gameService.getGame(id)
      .then(foundGame => {
        this.game = foundGame;
        this.starRating = new Array(this.game.rate);
      });
  }

  deleteGame():void {
    this.gameService.deleteGame(this.game._id)
        .then(response => {
          this.deleteSuccess = true;
        }).catch(error => {
          this.deleteFailur = true;
        })
  }

  goBack():void {
    this.location.back();
  }

}
