
export class Nutrition {
    _id: string;
    calories: number;
    fat: number;
    carbs: number;
    protein: number;
}

export class Origin {
    _id: string;
    continent: string;
    country: string;
}

export class Allergy {
    _id: string;
    name: string;
}

export class Menu {
    _id: string;
    name: string;
    type: string;
    price: number;
    description: string;
    nutrition: Nutrition;
    origin: Origin;
    allergies: Allergy[];
    ingredients: any[];
    drinks: Drink[];

    constructor(){
        this.nutrition = new Nutrition();
        this.origin = new Origin();
    }
}


export class MenuEditModel {
    _id: string;
    name: string;
    type: string;
    price: number;
    description: string;
    // nutrition: Nutrition;
    calories: number;
    fat: number;
    carbs: number;
    protein: number;
    // origin: Origin;
    country: string;
    continent: string;
    allergy: string;
    // allergies: Allergy[];
    // ingredients: any[];
    // drinks: Drink[];

}


export interface Drink {
    ingredients: string[];
    name: string;
    description: string;
    price: number;
    nutrition: Nutrition;
}



