import { Component } from '@angular/core';
import { MenuDataService } from './menu-data.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  username: string;
  password: string;

  isLoggedIn: boolean;

  constructor(private menuService: MenuDataService){
  
  }

  onLogin(): void {
    let user = {
      username: this.username,
      password: this.password
    }
    this.menuService.login(user)
      .then(response => {
        console.log(response)
        this.menuService.isLoggedIn = true;
        this.isLoggedIn = true;
      }).catch(err => {
        console.log(err);
      })
  }

  onLogout(): void {
    console.log(this.menuService.isLoggedIn);
    this.menuService.isLoggedIn = false;
    this.isLoggedIn = false;
  }
}
