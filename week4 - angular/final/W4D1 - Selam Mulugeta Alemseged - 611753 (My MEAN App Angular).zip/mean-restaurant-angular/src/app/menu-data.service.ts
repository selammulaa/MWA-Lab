import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { MenuEditModel } from './model/menu';

import { Menu } from './model/menu';
import { User } from './model/user';


@Injectable({
  providedIn: 'root'
})
export class MenuDataService {

  private apiBaseUrl: string = "http://localhost:3000/api";
  isLoggedIn: boolean = false;


  constructor(private http: HttpClient) {

  }

  public getMenus(): Promise<Menu[]>{
      const url = this.apiBaseUrl + "/menus";

      return this.http.get(url)
              .toPromise()
              .then(response => response as Menu)
              .catch(this.handleErrors);
  }

  public searchMenus(searchString: string): Promise<Menu[]>{
    const url = this.apiBaseUrl + "/menus?search=" + searchString;

    return this.http.get(url)
              .toPromise()
              .then(response => response as Menu)
              .catch(this.handleErrors);

  }

  public getMenu(id: String): Promise<Menu>{
    const url = this.apiBaseUrl + "/menus/"+id;

    return this.http.get(url)
              .toPromise()
              .then(respons => respons as Menu)
              .catch(this.handleErrors);
    
  }


  public saveMenu(menu: MenuEditModel): Promise<Menu>{
    const url = this.apiBaseUrl + "/menus/";

    return this.http.post(url, menu)
              .toPromise()
              .then(response => response as Menu)
              .catch(this.handleErrors);
  }


  public deleteMenu(id: string): Promise<any>{
    const url = this.apiBaseUrl + "/menus/"+id;

    return this.http.delete(url)
      .toPromise()
      .then(response => response as Menu)
      .catch(this.handleErrors);

  }

  public login(user: any): Promise<any>{
    const url: string = this.apiBaseUrl + "/users/login";

    return this.http.post(url, user)
        .toPromise()
        .then(response => response)
        .catch(this.handleErrors);
  }

  public register(user: User): Promise<User>{
    const url: string = this.apiBaseUrl + "/users/register";

    return this.http.post(url, user)
      .toPromise()
      .then(respons => respons as User)
      .catch(this.handleErrors);

  }

   private handleErrors(error: any):Promise<any>{
    console.log("");
    return Promise.reject(error.message || error);
  }
}
