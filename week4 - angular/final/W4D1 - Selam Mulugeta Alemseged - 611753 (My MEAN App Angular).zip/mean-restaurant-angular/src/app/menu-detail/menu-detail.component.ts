import { Component, OnInit } from '@angular/core';
import { Menu } from '../model/menu';

import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { MenuDataService } from '../menu-data.service';


@Component({
  selector: 'app-menu-detail',
  templateUrl: './menu-detail.component.html',
  styleUrls: ['./menu-detail.component.css']
})
export class MenuDetailComponent implements OnInit {
  title: string = "MEAN Menu";
  menu: Menu = new Menu();


  constructor(
    private route: ActivatedRoute,
    private menuDataService: MenuDataService,
    private location: Location) { }

  ngOnInit(): void {
    this.getGame();
  }

  getGame(): void {
    const id = this.route.snapshot.paramMap.get('id');
    this.menuDataService.getMenu(id)
      .then(foundMenu => {
        this.menu = foundMenu;
      });
  }


  goBack():void {
    this.location.back();
  }

}
