import { Component, OnInit } from '@angular/core';
import { MenuDataService } from '../menu-data.service';
import { Menu, MenuEditModel } from '../model/menu';

@Component({
  selector: 'app-menu-list',
  templateUrl: './menu-list.component.html',
  styleUrls: ['./menu-list.component.css']
})
export class MenuListComponent implements OnInit {

  menus: Menu[];
  search: string;
  menu: MenuEditModel = new MenuEditModel();
  isLoggedIn: boolean;
  title: string = "MEAN Menu";
  deleteSuccess: boolean = null;


  constructor(private menuService: MenuDataService) { }

  ngOnInit(): void {
    this.getMenus();
  }

  private getMenus(){
    this.menuService.getMenus()
        .then(menu => {
          this.menus = menu;
          this.isLoggedIn = this.menuService.isLoggedIn;
        })
  }

  searchMenus(){
    this.menuService.searchMenus(this.search)
    .then(menu => {
      this.menus = menu;
    })
  }

  save(){
      console.log(this.menu);
      this.menuService.saveMenu(this.menu)
        .then(response => {
          console.log(response);
          this.menu = new MenuEditModel();
          this.getMenus();
        }).catch(err => {
          console.log(err);
        })
  }

  deleteMenu(id: string){
      console.log(id);
      this.menuService.deleteMenu(id)
        .then(() => {
          this.deleteSuccess = true;
          this.getMenus();
        }).catch(err => {
          console.log(err);
          this.deleteSuccess = false;
        })
  }



}
