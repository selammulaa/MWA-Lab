export class User {
    username: string;
    password: string;
    success: boolean;
    token: string;
    role: string;

    constructor(){

    }
    
    // constructor(username: string, password: string){
    //     this.username = username;
    //     this.password = password;
    // }
}