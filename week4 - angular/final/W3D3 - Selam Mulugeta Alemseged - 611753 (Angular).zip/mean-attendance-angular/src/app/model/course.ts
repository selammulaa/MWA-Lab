export class Course {
    _id: string;
    courseNumber: string;
    courseName: string;
    year: number;
    semester: string;
    registrationCode: string;
    studentRegistrationCode: string;
    studentId: string;
}