angular.module("meanAttendance").controller("LoginController", LoginController);

function LoginController(){
    var vm = this;
    vm.title = "Hello"
}